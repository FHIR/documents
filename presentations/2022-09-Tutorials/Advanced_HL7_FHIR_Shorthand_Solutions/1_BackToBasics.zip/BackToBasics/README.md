# Back to Basics Solution

This is the solution to the Advanced HL7 FSH Exercise: Back to Basics.
In this exercise, you were asked to run `sushi --init` and then build
the results using SUSHI and the IG Publisher.

This solution contains the SUSHI-generated output in "fsh-generated",
as well as the IG Publisher output in "output" -- but you are
encouraged to try running SUSHI and the IG Publisher yourself.

To reduce file size, temporary folders such as "input-cache", "temp",
and "template" have been removed.