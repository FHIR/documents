# Tackling Tediosity Solution

This is the solution to the Advanced HL7 FSH Exercise: Tackling
Tediosity. In this exercise, you were asked to use soft indexing
and rule sets to improve a FSH Instance of OperationDefinition
called FetchDocumentReference.

This solution demonstrates two potential approaches to designing the
rule set. Both are reasonable and appropriate, but you may find
that you prefer one over the other.

This solution contains the SUSHI-generated output in "fsh-generated",
as well as the IG Publisher output in "output" -- but you are
encouraged to try running SUSHI and the IG Publisher yourself.

To reduce file size, temporary folders such as "input-cache", "temp",
and "template" have been removed.

## Starter FSH Code

The Starter FSH code can be found at https://bit.ly/fsh-docref-starter,
but is also included below for reference:

```
Instance: fetch-doc-ref
InstanceOf: OperationDefinition
Usage: #definition
* name = "ExampleFetchDocumentReference"
* title = "Example Fetch DocumentReference"
* description = "An example FetchDocumentReference operation (based on US Core)"
* status = #draft
* kind = #operation
* code = #docref
* system = false
* type = true
* instance = false
* parameter[0].name = #patient
* parameter[0].use = #in
* parameter[0].min = 1
* parameter[0].max = "1"
* parameter[0].documentation = "The id of the patient to fetch documents for"
* parameter[0].type = #id
* parameter[1].name = #start
* parameter[1].use = #in
* parameter[1].min = 0
* parameter[1].max = "1"
* parameter[1].documentation = "The earliest date of care to fetch documents for"
* parameter[1].type = #dateTime
* parameter[2].name = #end
* parameter[2].use = #in
* parameter[2].min = 0
* parameter[2].max = "1"
* parameter[2].documentation = "The latest date of care to fetch documents for"
* parameter[2].type = #dateTime
* parameter[3].name = #type
* parameter[3].use = #in
* parameter[3].min = 0
* parameter[3].max = "1"
* parameter[3].documentation = "The type of document to fetch"
* parameter[3].type = #CodeableConcept
* parameter[3].binding.strength = #required
* parameter[3].binding.valueSet = "http://hl7.org/fhir/ValueSet/c80-doc-typecodes"
* parameter[4].name = #on-demand
* parameter[4].use = #in
* parameter[4].min = 0
* parameter[4].max = "1"
* parameter[4].documentation = "Include only 'on-demand' documents?"
* parameter[4].type = #boolean
* parameter[5].name = #return
* parameter[5].use = #out
* parameter[5].min = 1
* parameter[5].max = "1"
* parameter[5].documentation = "A Bundle of matching DocumentReferences"
* parameter[5].type = #Bundle
```