# Slicing Solution

This is the solution to the Advanced HL7 FSH Exercise: Slicing.
In this exercise, you were asked to update the PartialCCD profile
to slice the section element into three different sections.

This solution contains the SUSHI-generated output in "fsh-generated",
as well as the IG Publisher output in "output" -- but you are
encouraged to try running SUSHI and the IG Publisher yourself.

To reduce file size, temporary folders such as "input-cache", "temp",
and "template" have been removed.

## Starter FSH Code

The Starter FSH code can be found at https://bit.ly/fsh-ccd-starter,
but is also included below for reference:

```
Alias: $ACT = http://terminology.hl7.org/CodeSystem/v3-ActClass
Alias: $AIC = http://terminology.hl7.org/CodeSystem/allergyintolerance-clinical
Alias: $AIV = http://terminology.hl7.org/CodeSystem/allergyintolerance-verification
Alias: $LNC = http://loinc.org
Alias: $RXN = http://www.nlm.nih.gov/research/umls/rxnorm
Alias: $SCT = http://snomed.info/sct

Profile: PartialCCD
Parent: Composition
Id: partial-ccd
Title: "Partial Continuity of Care Document"
Description: "Partial Continuity of Care Document for training purposes only"
* type = $LNC#34133-9 // Summary of episode note
* event 1..1
* event.code = $ACT#PCPR // care provision
* event.period 1..
* event.period.start 1..
* event.period.end 1..
//
// Add section slicing rules here
// (hint: slice by pattern on code)
//
// Add section slice definitions for following slices:
// - allergies, code: LOINC 48765-2, entry: Reference(AllergyIntolerance)
// - medications, code: LOINC 10160-0, entry: Reference(MedicationRequest)
// - problems, code: LOINC 11450-4, entry: Reference(Condition)
//

Instance: PartialCCDExample
InstanceOf: PartialCCD
Title: "Partial CCD Example"
Description: "A simple, clinically inaccurate example of PartialCCD"
Usage: #example
* status = #final
* subject = Reference(PatientBob)
* author = Reference(AcmeOrganization)
* title = "Partial Continuity of Care Document for Bob"
* date = "2022-09-21T00:00:00.0Z"
* event.period.start = "2022-08-15T00:00:00.0Z"
* event.period.end = "2022-09-21T00:00:00.0Z"
//
// Add AllergyToLatexExample (defined below) to allergies section
// Add StatinExample (defined below) to medications section
// Add DiabetesExample (defined below) to problems section
// Add HypertensionExample (defined below) to problems section
//

// NOTE: The following examples are all very minimal and exist
// only to satisfy the references in PartialCCDExample above.

Instance: PatientBob
InstanceOf: Patient
Title: "Patient Bob"
Description: "Patient Bob"
Usage: #example
* name.given = "Bob"

Instance: AcmeOrganization
InstanceOf: Organization
Title: "Acme, Inc."
Description: "Acme, Inc."
Usage: #example
* name = "Acme, Inc."

Instance: AllergyToLatexExample
InstanceOf: AllergyIntolerance
Title: "Allergy to Latex Example"
Description: "Minimal Allergy to Latext Example"
Usage: #example
* patient = Reference(PatientBob)
* clinicalStatus = $AIC#active
* verificationStatus = $AIV#confirmed
* code = $RXN#7980 "penicillin G"

Instance: StatinExample
InstanceOf: MedicationRequest
Title: "Statin Example"
Description: "Statin Example"
Usage: #example
* subject = Reference(PatientBob)
* status = #active
* intent = #order
* medicationCodeableConcept = $RXN#617311 "atorvastatin calcium 40 MG Oral Tablet"

Instance: DiabetesExample
InstanceOf: Condition
Title: "Diabetes Example"
Description: "Diabetes Example"
Usage: #example
* subject = Reference(PatientBob)
* code = $SCT#44054006 "Diabetes mellitus type 2 (disorder)"

Instance: HypertensionExample
InstanceOf: Condition
Title: "Hypertension Example"
Description: "Hypertension Example"
Usage: #example
* subject = Reference(PatientBob)
* code = $SCT#10725009 "Benign hypertension (disorder)"
```