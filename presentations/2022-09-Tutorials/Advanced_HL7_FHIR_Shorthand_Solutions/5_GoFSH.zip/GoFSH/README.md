# GoFSH Solution

This is the solution to the Advanced HL7 FSH Exercise: GoFSH.
In this exercise, you were asked to run GoFSH against US Core
5.0.1 and fix two errors.

NOTE: This solution only fixes the errors that were noted in
the exercise. There are many other warnings that should also
be addressed, but have not been addressed here. In addition,
there are opportunities for improving the generated FSH code
that also are not demonstrated here. In other words, this is
an INCOMPLETE solution.
