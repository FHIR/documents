# IG Configuration Solution

This is the solution to the Advanced HL7 FSH Exercise: IG
Configuration. In this exercise, you were asked to add pages and
menus to your IG.

This solution contains the SUSHI-generated output in "fsh-generated",
as well as the IG Publisher output in "output" -- but you are
encouraged to try running SUSHI and the IG Publisher yourself.

To reduce file size, temporary folders such as "input-cache", "temp",
and "template" have been removed.
