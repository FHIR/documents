# Level 1 Header
## Level 2 Header
### Level 3 Header

Use two asterisks to specify **bold text**.

Use underscores to specify _italic text_.

Use backticks for `inline code`.

Link to [HL7 FHIR](https://www.hl7.org/fhir/).

Ordered list:
1. item a
2. item b

Unordered list:
- item a
- item b

```
Use three backticks before and after
a multi-line block of code.
```

> Use leading greater-than symbol for
> a quoted block of text.

| Question                 | Answer                 |
| ------------------------ | ---------------------- |
| Is this a table?         | Yes                    |
| Do I have to align it?   | No, but it looks nice. |
{: .grid }

![HL7 Logo](hl7-logo.png)

