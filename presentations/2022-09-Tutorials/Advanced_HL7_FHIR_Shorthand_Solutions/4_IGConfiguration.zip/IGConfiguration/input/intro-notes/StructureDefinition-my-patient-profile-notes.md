See I told you it was simple.

If it wasn't so simple, I might have more things to say here.